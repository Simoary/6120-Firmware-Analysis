<TotalPacketsSent>0</TotalPacketsSent>
<TotalPacketsReceived>0</TotalPacketsReceived>