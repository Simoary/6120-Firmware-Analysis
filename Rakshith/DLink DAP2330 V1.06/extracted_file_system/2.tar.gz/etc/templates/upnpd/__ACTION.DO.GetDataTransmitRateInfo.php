<NewBasicDataTransmitRates>1</NewBasicDataTransmitRates>
<NewOperationalDataTransmitRates>1,2,5.5,11,9,18,36,54</NewOperationalDataTransmitRates>
<NewPossibleDataTransmitRates>1,2,5.5,11</NewPossibleDataTransmitRates>