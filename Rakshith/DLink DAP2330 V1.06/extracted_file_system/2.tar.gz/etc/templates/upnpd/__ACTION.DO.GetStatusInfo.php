<? $errorCode=200; $SOAP_BODY=$template_root."/upnpd/__ACTION.GetStatusInfo.php"; ?>
