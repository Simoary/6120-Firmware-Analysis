<? /* vi: set sw=4 ts=4: */
require("/etc/templates/troot.php");
require($template_root."/upnpd/__NOTIFY.req.event.php");
$WID=1;
require($template_root."/upnpd/__NOTIFY.WANIPConnection.1.php");
?>
