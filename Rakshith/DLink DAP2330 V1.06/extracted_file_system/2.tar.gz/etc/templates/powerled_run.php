#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */

$ledon = query("/sys/led/power");
if($ledon==1) { echo "gpioc -c 23\n"; }
else { echo "gpioc -w 23\n"; }

?>
