<?
$template_root=query("/runtime/template_root");
if ($template_root=="") { $template_root="/etc/templates"; }
?>
