#!/bin/sh

# added by Enos, 2008/01/31 , wps
#xmldbc -x /runtime/genuuid "get:genuuid -r"
#xmldbc -x /runtime/genpin  "get:wps -g"

# added by Enos, 2008/01/31 , upnp_wfa.sh
#LANMAC=`xmldbc -i -g /runtime/layout/lanmac`
#xmldbc -i -s /runtime/upnpdev/root:1/uuid `genuuid -s WFADevice -m $LANMAC`
