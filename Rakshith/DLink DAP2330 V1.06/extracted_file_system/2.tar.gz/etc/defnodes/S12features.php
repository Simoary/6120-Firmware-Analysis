<?
/* set functions */
set("/runtime/func/wps",			"1");
set("/runtime/func/no_jumpstart",	"1");
set("/runtime/func/normal_g",		"1");
?>
