<?
$m_context_title = "IP Filter Settings";
$m_wband = "Wireless Band";
$m_band_2_4G = "2.4GHz";
$m_band_5G = "5GHz";
$m_ssid_index = "SSID Index";
$m_pri = "Primary SSID";
$m_ssid1 = "SSID1";
$m_ssid2 = "SSID2";
$m_ssid3 = "SSID3";
$m_ssid4 = "SSID4";
$m_ssid5 = "SSID5";
$m_ssid6 = "SSID6";
$m_ssid7 = "SSID7";
$m_ssid = "SSID";
$m_ip = "IP Address";
$m_mask = "Subnet Mask";
$m_id = "ID";
$m_ip_filter = "IP Filter";
$m_del = "Delete";

$m_upload_ip_titles = "Upload IP Filter File";
$m_upload_ip_file = "Upload File";
$m_upload = "Upload";
$m_download_ip_title = "Download IP Filter File";
$m_save_ip = "Load IP Filter File to Local Hard Driver";
$m_save = "Download";

$a_del_confirm      = "Are you sure that you want to delete this ip filter rule?";
$a_same_rule = "The rule has already been added in the list!";
$a_invalid_ip      = "Invalid IP Filter !";
$a_invalid_mask	= "Invalid Mask value!";
$a_max_ip = "Maximum number of IP Filter List is 64!";
$a_format_error_file ="File extension error! It must be \\\".acl\\\" . Please try again!";
$a_blank_mac_file = "Empty file is not accepted!";
?>
