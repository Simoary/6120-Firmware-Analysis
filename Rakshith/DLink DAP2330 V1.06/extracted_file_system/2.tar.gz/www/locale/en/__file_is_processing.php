The operation is handling ...<br><br>
Please <font color=red><b>DO NOT POWER OFF</b></font> the device.<br><br>
And please wait for
<input type='text' readonly name='WaitInfo' value='150' size='3' style='border-width:0; background-color=#DFDFDF; color:#FF3030; text-align:center'>
seconds...
