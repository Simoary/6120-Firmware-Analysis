<?
$a_invalid_user_name	="Please input the User Name.";

$m_html_title		="LOGIN";
$m_context_title	="Login";
$m_login_router		="Log in to the router:";
$m_login_ap		="Login to the Access Point:";
$m_log_in		=" Login ";
?>
