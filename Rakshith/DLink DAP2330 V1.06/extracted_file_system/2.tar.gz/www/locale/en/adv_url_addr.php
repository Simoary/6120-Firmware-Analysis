<?
$m_context_title = "Web Redirection";
$m_enable_auth = "Enable Web Authentication";
$m_enable_url = "Enable Web Redirection";
$m_url_addr = "Web Site";
$m_account_title = "Add Web Redirection Account";
$m_name = "User Name";
$m_password = "Password";
$m_list_title = "Web Redirection Account List";
$m_edit = "(Edit)";
$m_delete = "Delete";
$m_enable = "Enable";
$m_disable = "Disable";
$m_status = "Status";
$a_can_not_same_name = "Can't use the same name !";
$a_max_account_number = "Maximum number of user account is 256!";
$a_empty_user_name ="Please input a user name.";
$a_first_end_blank  = "The first character and last character can't be blank.";
$a_invalid_name = "There are some invalid characters in the Name field. Please check it.";
$a_invalid_password_len	= "The length of password should be 8~64.";
$a_invalid_password	= "The password should be ASCII characters.";
$a_invalid_url_addr = "Invalid Web Redirection Site!";
$a_invalid_http = "Web site can't start with 'http'!";
$a_empty_url_addr = "Please input a web site!";
$a_at_least_1_acc_enable = "When Web Authentication enable,at least 1 account must be enable";
?>


