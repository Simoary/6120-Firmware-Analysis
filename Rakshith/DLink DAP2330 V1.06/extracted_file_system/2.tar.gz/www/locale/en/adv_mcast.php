<?
$m_context_title = "Multicast Rate ";
$m_multicast_rate  = "Multicast Rate ";
$m_mcast_a = "Multicast Rate for a band";
$m_mcast_g = "Multicast Rate for g band";
$m_enable = "Enable";
$m_disable = "Disable";
$m_band = "Wireless Band";
$m_band_5G = "5GHz";
$m_band_2.4G = "2.4GHz";
$m_mbps = "Mbps";
?>