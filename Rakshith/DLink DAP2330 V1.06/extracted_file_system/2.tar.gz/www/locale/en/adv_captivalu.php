<?
$m_context_title = "Login Page Upload";
$m_upload_html_titles = "Upload HTML From Local Hard Drive";
$m_upload_html_file = "Upload HTML from file";
$m_upload_pic_titles = "Upload Picture From Local Hard Drive";
$m_upload_pic_file = "Upload picture from file";
$m_upload = "Upload";

$a_invalid_html = "File extension error! It must be \\\".html\\\" . Please try again!";
$a_invalid_pic = "File extension error! It must be \\\".jpg\\\" . Please try again!";
?>
