<?
$m_context_title = "Load Balance";
$m_disable = "Disable";
$m_enable = "Enable";
$m_enable_load_balance = "Enable Load Balance";
$m_thre = "Active Threshold";

$a_empty_thre = "Please input an active threshold.";
$a_invalid_thre = "Active Threshold range must be 1~128.";
?>
