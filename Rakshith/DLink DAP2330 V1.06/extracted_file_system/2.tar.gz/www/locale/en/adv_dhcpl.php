<?
$m_context_title = "Current IP Mapping List";
$m_host_name = "Host Name";
$m_mac = "Binding MAC Address";
$m_ip = "Assigned IP Address";
$m_time = "Lease Time";
$m_dynamic_pools = "Current DHCP Dynamic Pools";
$m_static_pools = "Current DHCP Static Pools";
$m_days			="days";
$m_hrs			="hours";
$m_mins			="minutes";
$m_secs			="seconds";
$m_timeout		="TimeOut";
?>
