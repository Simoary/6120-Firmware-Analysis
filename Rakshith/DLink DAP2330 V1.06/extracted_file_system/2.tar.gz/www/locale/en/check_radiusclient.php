<? 
$m_context_title="Check Radiusclient";
$m_pls_wait = "Please Wait";
?>